from django.apps import AppConfig


class CxConfig(AppConfig):
    name = 'cx'
