from django.apps import AppConfig


class HgConfig(AppConfig):
    name = 'hg'
